CONNECT 'C:\SDO\Base\BaseSDO.gdb'
USER 'DIMA'  PASSWORD '1981';

CREATE TABLE Instituts (
       UIDinstitut          INTEGER NOT NULL,
       NameIns              BLOB,
       TypeIns              INTEGER,
       PRIMARY KEY (UIDinstitut)
);

CREATE UNIQUE INDEX XPKInstituts ON Instituts
(
       UIDinstitut
);

CREATE GENERATOR UIDinstitut_gen;
    SET TERM !! ;
    CREATE TRIGGER  Instituts_GEN_ID FOR  Instituts  BEFORE  INSERT    AS
      BEGIN
          new.UIDinstitut = gen_id(UIDinstitut_gen, 1);
      END !!
      SET TERM ; !!




CREATE TABLE Fakultets (
       UIDfak               INTEGER NOT NULL,
       UIDinstitut          INTEGER,
       NameFak              BLOB,
       PRIMARY KEY (UIDfak),
       FOREIGN KEY (UIDinstitut)
                             REFERENCES Instituts
);

CREATE UNIQUE INDEX XPKFakultets ON Fakultets
(
       UIDfak
);

CREATE INDEX XIF1Fakultets ON Fakultets
(
       UIDinstitut
);

CREATE GENERATOR UIDfak_gen;
    SET TERM !! ;
    CREATE TRIGGER  Fakultets_GEN_ID FOR  Fakultets  BEFORE  INSERT    AS
      BEGIN
          new.UIDfak = gen_id(UIDfak_gen, 1);
      END !!
      SET TERM ; !!




CREATE TABLE Kafedr (
       UID3                 INTEGER NOT NULL,
       UIDinstitut          INTEGER,
       UIDfak               INTEGER,
       Kafedra              BLOB,
       PRIMARY KEY (UID3),
       FOREIGN KEY (UIDinstitut)
                             REFERENCES Instituts
     
);

CREATE UNIQUE INDEX XPKKafedr ON Kafedr
(
       UID3
);


CREATE INDEX XIF2Kafedr ON Kafedr
(
       UIDinstitut
);

CREATE GENERATOR UID3_gen;
    SET TERM !! ;
    CREATE TRIGGER  Kafedr_GEN_ID FOR  Kafedr  BEFORE  INSERT    AS
      BEGIN
          new.UID3 = gen_id(UID3_gen, 1);
      END !!
      SET TERM ; !!




CREATE TABLE Discipline (
       UID7                 INTEGER NOT NULL,
       UID3                 INTEGER,
       Discipline           VARCHAR(300) CHARACTER SET WIN1251,
       FullName             BLOB,
       Otl                  INTEGER,
       Hor                  INTEGER,
       Udv                  INTEGER,
       PRIMARY KEY (UID7),
       FOREIGN KEY (UID3)
                             REFERENCES Kafedr
);

CREATE UNIQUE INDEX XPKDiscipline ON Discipline
(
       UID7
);

CREATE INDEX XIF1Discipline ON Discipline
(
       UID3
);

CREATE GENERATOR UID7_gen;
    SET TERM !! ;
    CREATE TRIGGER  Discipline_GEN_ID FOR  Discipline  BEFORE  INSERT    AS
      BEGIN
          new.UID7 = gen_id(UID7_gen, 1);
      END !!
      SET TERM ; !!




CREATE TABLE Razdel (
       UID8                 INTEGER NOT NULL,
       UID7                 INTEGER,
       NameRazdel           VARCHAR(300) CHARACTER SET WIN1251,
       ShifrRazdel          VARCHAR(60) CHARACTER SET WIN1251,
       NameLevel            VARCHAR(60) CHARACTER SET WIN1251,
       PRIMARY KEY (UID8),
       FOREIGN KEY (UID7)
                             REFERENCES Discipline
);

CREATE UNIQUE INDEX XPKRazdel ON Razdel
(
       UID8
);

CREATE INDEX XIF2Razdel ON Razdel
(
       UID7
);

CREATE GENERATOR UID8_gen;
    SET TERM !! ;
    CREATE TRIGGER  Razdel_GEN_ID FOR  Razdel  BEFORE  INSERT    AS
      BEGIN
          new.UID8 = gen_id(UID8_gen, 1);
      END !!
      SET TERM ; !!



CREATE TABLE BOOKS (
       UIDBOOK              INTEGER NOT NULL,
       UID7                 INTEGER,
       Name                 VARCHAR(1000) CHARACTER SET WIN1251,
       PACH                 VARCHAR(1000) CHARACTER SET WIN1251,
       PS                   VARCHAR(1000) CHARACTER SET WIN1251,
       PRIMARY KEY (UIDBOOK ),
       FOREIGN KEY (UID7)
                             REFERENCES Discipline
);

CREATE UNIQUE INDEX XPKBOOKS ON BOOKS
(
       UIDBOOK
);

CREATE INDEX XIF2BOOKS ON BOOKS
(
       UID7
);

CREATE GENERATOR UIDBOOK_gen;
    SET TERM !! ;
    CREATE TRIGGER  BOOKS_GEN_ID FOR  BOOKS  BEFORE  INSERT    AS
      BEGIN
          new.UIDBOOK  = gen_id(UIDBOOK_gen, 1);
      END !!
      SET TERM ; !!




CREATE TABLE Tests (
       UIDtest              INTEGER NOT NULL,
       UID8                 INTEGER,
       TypeTest             INTEGER,
       Name                 BLOB,
       times                INTEGER,
       BallTest             INTEGER,
       DataTest             BLOB,
       PS                   BLOB,
       NQuest               INTEGER,
       PRIMARY KEY (UIDtest),
       FOREIGN KEY (UID8)
                             REFERENCES Razdel
);

CREATE UNIQUE INDEX XPKTests ON Tests
(
       UIDtest
);

CREATE INDEX XIF1Tests ON Tests
(
       UID8
);

CREATE GENERATOR UIDtest_gen;
    SET TERM !! ;
    CREATE TRIGGER  Tests_GEN_ID FOR  Tests  BEFORE  INSERT    AS
      BEGIN
          new.UIDtest = gen_id(UIDtest_gen, 1);
      END !!
      SET TERM ; !!




CREATE TABLE Param_Random (
       UIDtest              INTEGER,
       UID8                 INTEGER,
       N_Tests              INTEGER,
       FOREIGN KEY (UID8)
                             REFERENCES Razdel,
       FOREIGN KEY (UIDtest)
                             REFERENCES Tests
);

CREATE INDEX XIF1Param_Random ON Param_Random
(
       UIDtest
);

CREATE INDEX XIF2Param_Random ON Param_Random
(
       UID8
);


CREATE TABLE Gruops (
       UID1                 INTEGER NOT NULL,
       UID3                 INTEGER,
       Gruop                VARCHAR(20) CHARACTER SET WIN1251,
       Data_Begin           VARCHAR(20) CHARACTER SET WIN1251,
       PRIMARY KEY (UID1),
       FOREIGN KEY (UID3)
                             REFERENCES Kafedr
);

CREATE UNIQUE INDEX XPKGruops ON Gruops
(
       UID1
);


CREATE INDEX XIF1Gruops ON Gruops
(
       UID3
);

CREATE GENERATOR UID1_gen;
    SET TERM !! ;
    CREATE TRIGGER  Gruops_GEN_ID FOR  Gruops  BEFORE  INSERT    AS
      BEGIN
          new.UID1 = gen_id(UID1_gen, 1);
      END !!
      SET TERM ; !!




CREATE TABLE Students (
       UID2                 INTEGER NOT NULL,
       UID1                 INTEGER,
       Name                 BLOB,
       FeName               BLOB,
       Familia              BLOB,
       Parol                BLOB,
       Nstudent             BLOB,
       Zachetka             BLOB,
       PRIMARY KEY (UID2),
       FOREIGN KEY (UID1)
                             REFERENCES Gruops
);

CREATE UNIQUE INDEX XPKStudents ON Students
(
       UID2
);

CREATE INDEX XIF1Students ON Students
(
       UID1
);

CREATE GENERATOR UID2_gen;
    SET TERM !! ;
    CREATE TRIGGER  Students_GEN_ID FOR  Students  BEFORE  INSERT    AS
      BEGIN
          new.UID2 = gen_id(UID2_gen, 1);
      END !!
      SET TERM ; !!


CREATE TABLE StudentTests (
       UIDtest              INTEGER,
       UID2                 INTEGER,
       DateEND              BLOB,
       Metod                BLOB,
       TUTER                INTEGER,
       FOREIGN KEY (UIDtest)
                             REFERENCES Tests,
       FOREIGN KEY (UID2)
                             REFERENCES Students
);

CREATE INDEX XIF1StudentTests ON StudentTests
(
       UID2
);

CREATE INDEX XIF2StudentTests ON StudentTests
(
       UIDtest
);


CREATE TABLE Quests (
       UID9                 INTEGER NOT NULL,
       UID8                 INTEGER,
       TypeQuest            INTEGER,
       Ball                 INTEGER,
       Text                 BLOB,
       Pink                 INTEGER,
       Time_Test            INTEGER,
       PRIMARY KEY (UID9),
       FOREIGN KEY (UID8)
                             REFERENCES Razdel
);

CREATE UNIQUE INDEX XPKQuests ON Quests
(
       UID9
);

CREATE INDEX XIF1Quests ON Quests
(
       UID8
);

CREATE GENERATOR UID9_gen;
    SET TERM !! ;
    CREATE TRIGGER  Quests_GEN_ID FOR  Quests  BEFORE  INSERT    AS
      BEGIN
          new.UID9 = gen_id(UID9_gen, 1);
      END !!
      SET TERM ; !!




CREATE TABLE TestQuest (
       UIDtest              INTEGER,
       UID9                 INTEGER,
       NumberQuest          INTEGER,
       FOREIGN KEY (UID9)
                             REFERENCES Quests,
       FOREIGN KEY (UIDtest)
                             REFERENCES Tests
);

CREATE INDEX XIF1TestQuest ON TestQuest
(
       UIDtest
);

CREATE INDEX XIF2TestQuest ON TestQuest
(
       UID9
);


CREATE TABLE Answer (
       UID9                 INTEGER NOT NULL,
       Number               INTEGER,
       TextAnsw             BLOB,
       Roles                INTEGER,
       FOREIGN KEY (UID9)
                             REFERENCES Quests
);

CREATE INDEX XIF1Answer ON Answer
(
       UID9
);


CREATE TABLE PINCS (
       UID9                 INTEGER NOT NULL,
       Number               INTEGER,
       X                    INTEGER,
       Y                    INTEGER,
       TypeP                INTEGER,
       PINC                 BLOB,
       FOREIGN KEY (UID9)
                             REFERENCES Quests
);

CREATE INDEX XIF1PINCS ON PINCS
(
       UID9
);

CREATE TABLE Tutors (
       UID6                 INTEGER NOT NULL,
       Name                 BLOB,
       FeName               BLOB,
       Familia              BLOB,
       Parol                BLOB,
       PRIMARY KEY (UID6)
);

CREATE UNIQUE INDEX XPKTutors ON Tutors
(
       UID6
);

CREATE GENERATOR UID6_gen;
    SET TERM !! ;
    CREATE TRIGGER  Tutors_GEN_ID FOR  Tutors  BEFORE  INSERT    AS
      BEGIN
          new.UID6 = gen_id(UID6_gen, 1);
      END !!
      SET TERM ; !!


CREATE TABLE Administrators (
       UID5                 INTEGER NOT NULL,
       Name                 BLOB,
       FeName               BLOB,
       Familia              BLOB,
       Parol                BLOB,
       PRIMARY KEY (UID5)
);

CREATE UNIQUE INDEX XPKAdministrators ON Administrators
(
       UID5
);

CREATE GENERATOR UID5_gen;
    SET TERM !! ;
    CREATE TRIGGER  Administrators_GEN_ID FOR  Administrators  BEFORE  INSERT    AS
      BEGIN
          new.UID5 = gen_id(UID5_gen, 1);
      END !!
      SET TERM ; !!




CREATE TABLE Prepodavatels (
       UID4                 INTEGER NOT NULL,
       UID3                 INTEGER,
       Name                 BLOB,
       FeName               BLOB,
       Familia              BLOB,
       Parol                BLOB,
       PRIMARY KEY (UID4),
       FOREIGN KEY (UID3)
                             REFERENCES Kafedr
);

CREATE UNIQUE INDEX XPKPrepodavatels ON Prepodavatels
(
       UID4
);

CREATE INDEX XIF1Prepodavatels ON Prepodavatels
(
       UID3
);

CREATE GENERATOR UID4_gen;
    SET TERM !! ;
    CREATE TRIGGER  Prepodavatels_GEN_ID FOR  Prepodavatels  BEFORE  INSERT    AS
      BEGIN
          new.UID4 = gen_id(UID4_gen, 1);
      END !!
      SET TERM ; !!




CREATE TABLE ConectTabel1 (
       Gruop                VARCHAR(20) CHARACTER SET WIN1251,
       UID7                 INTEGER NOT NULL,
       UID4                 INTEGER NOT NULL,
       FOREIGN KEY (UID7)
                             REFERENCES Discipline,
       FOREIGN KEY (UID4)
                             REFERENCES Prepodavatels
);

CREATE INDEX XIF2ConectTabel1 ON ConectTabel1
(
       UID4
);

CREATE INDEX XIF3ConectTabel1 ON ConectTabel1
(
       UID7
);


CREATE TABLE Statistik (
       UIDstat              INTEGER NOT NULL,
       UID6                 INTEGER,
       UID2                 INTEGER,
       UIDtest              INTEGER,
       StudentBall          FLOAT,
       Procent              FLOAT,
       DataSdachi           VARCHAR(100) CHARACTER SET WIN1251,
       PS                   VARCHAR(300) CHARACTER SET WIN1251,
       PRIMARY KEY (UIDstat),
       FOREIGN KEY (UID6)
                             REFERENCES Tutors,
       FOREIGN KEY (UIDtest)
                             REFERENCES Tests,
       FOREIGN KEY (UID2)
                             REFERENCES Students
);

CREATE UNIQUE INDEX XPKStatistik ON Statistik
(
       UIDstat
);

CREATE INDEX XIF1Statistik ON Statistik
(
       UID2
);

CREATE INDEX XIF2Statistik ON Statistik
(
       UIDtest
);

CREATE INDEX XIF3Statistik ON Statistik
(
       UID6
);

CREATE GENERATOR UIDstat_gen;
    SET TERM !! ;
    CREATE TRIGGER  Statistik_GEN_ID FOR  Statistik  BEFORE  INSERT    AS
      BEGIN
          new.UIDstat = gen_id(UIDstat_gen, 1);
      END !!
      SET TERM ; !!




CREATE TABLE FullStatistika (
       UIDstat              INTEGER,
       UIDquest             INTEGER,
       StudentBall          FLOAT,
       PROCENT              FLOAT,
       StudAnsw             BLOB,
       FOREIGN KEY (UIDstat)
                             REFERENCES Statistik
);

CREATE INDEX XIF1FullStatistika ON FullStatistika
(
       UIDstat
);


/* View: INSTITUTSUN, Owner: DIMA */

CREATE VIEW INSTITUTSUN (
  UID,
  NAME
) AS

SELECT UIDINSTITUT, NAMEINS
FROM INSTITUTS
WHERE TYPEINS=1
;

/* View: FAKULTETSUN, Owner: DIMA */

CREATE VIEW FAKULTETSUN (
  UID,
  NAME
) AS

SELECT UIDINSTITUT, NAMEINS
FROM INSTITUTS
WHERE TYPEINS=0
;

SET TERM ^ ;

/* Stored procedures */

CREATE PROCEDURE DELINSTITUTS
(
  ID INTEGER
)
AS
BEGIN EXIT; END ^

CREATE PROCEDURE FAKULTETS_INS
(
  ID_INS INTEGER
)
RETURNS
(
  UID_FAKULTET INTEGER,
  NAME_FAKULTET BLOB
)
AS
BEGIN EXIT; END ^

CREATE PROCEDURE KAFEDR_INS_FAK
(
  ID_INS INTEGER,
  ID_FAK INTEGER
)
RETURNS
(
  UID_KAFEDR INTEGER,
  NAME_KAFEDR BLOB
)
AS
BEGIN EXIT; END ^

CREATE PROCEDURE PREPODAVATELS_KAF
(
  ID_KAF INTEGER
)
RETURNS
(
  UID_PREPOD INTEGER,
  NAME_PREPOD BLOB,
  FENAME_PREPOD BLOB,
  FAMIL_PREPOD BLOB,
  PAROL_PREPOD BLOB
)
AS
BEGIN EXIT; END ^


ALTER PROCEDURE DELINSTITUTS
(
  ID INTEGER
)
AS
 BEGIN
DELETE FROM INSTITUTS
WHERE
UIDINSTITUT=:id;
END
 ^


ALTER PROCEDURE FAKULTETS_INS
(
  ID_INS INTEGER
)
RETURNS
(
  UID_FAKULTET INTEGER,
  NAME_FAKULTET BLOB
)
AS
 BEGIN
FOR SELECT UIDFAK, NAMEFAK
    FROM FAKULTETS
    WHERE UIDINSTITUT=:ID_INS
    INTO :UID_Fakultet, :Name_Fakultet
DO
   BEGIN
    SUSPEND;
   END
END
 ^


ALTER PROCEDURE KAFEDR_INS_FAK
(
  ID_INS INTEGER,
  ID_FAK INTEGER
)
RETURNS
(
  UID_KAFEDR INTEGER,
  NAME_KAFEDR BLOB
)
AS
 BEGIN
FOR SELECT UID3, KAFEDRA
    FROM KAFEDR
    WHERE UIDINSTITUT=:ID_INS AND UIDFAK=:ID_FAK
    INTO :UID_KAFEDR, :Name_KAFEDR
DO
   BEGIN
    SUSPEND;
   END
END
 ^


ALTER PROCEDURE PREPODAVATELS_KAF
(
  ID_KAF INTEGER
)
RETURNS
(
  UID_PREPOD INTEGER,
  NAME_PREPOD BLOB,
  FENAME_PREPOD BLOB,
  FAMIL_PREPOD BLOB,
  PAROL_PREPOD BLOB
)
AS
BEGIN
FOR SELECT UID4, NAME, FENAME, FAMILIA, PAROL
    FROM PREPODAVATELS
    WHERE UID3=:ID_KAF
    INTO :UID_PREPOD, :Name_PREPOD, :FeName_PREPOD, :Famil_PREPOD, :Parol_PREPOD
DO
   BEGIN
    SUSPEND;
   END
END
 ^

CREATE PROCEDURE ADD_DISCIPLINE (ID_FAK integer,
                                  DIS_NAME VARCHAR(300) CHARACTER SET WIN1251,
                                    DIS_FUL_NAME BLOB)
RETURNS

AS
DECLARE VARIABLE UID integer;
BEGIN
INSERT INTO DISCIPLINE VALUES (1, :ID_FAK, :DIS_NAME, :DIS_FUL_NAME, 95, 80, 75);

SELECT UID7 FROM DISCIPLINE WHERE (UID3=:ID_FAK)AND(DISCIPLINE=:DIS_NAME)
INTO :UID;

INSERT INTO RAZDEL VALUES (1, :UID, :DIS_NAME, '��', 'WSMISO�S�\');
END ^


CREATE PROCEDURE PREPODAVATELS_GROUP (ID_PR integer)
RETURNS
        (UID_GR integer, GROUPA VARCHAR(20) CHARACTER SET WIN1251)
AS
BEGIN
FOR SELECT DISTINCT GRUOP
    FROM CONECTTABEL1
    WHERE UID4=:ID_PR
    INTO :GROUPA
DO
   BEGIN
       FOR SELECT UID1
           FROM GRUOPS
           WHERE GRUOP=:GROUPA
           INTO :UID_GR
       DO
           BEGIN
             SUSPEND;
           END
   END
END ^

CREATE PROCEDURE PREPODAVATELS_DISCIPLIN (ID_PR integer)
RETURNS
        (UID_D integer,
        DISCIPLIN VARCHAR(300) CHARACTER SET WIN1251,
        OTL	INTEGER,
        HOR	INTEGER,
        UDV	INTEGER)
AS
BEGIN
FOR SELECT DISTINCT UID7
    FROM CONECTTABEL1
    WHERE UID4=:ID_PR
    INTO :UID_D
DO
   BEGIN
       FOR SELECT DISCIPLINE, OTL, HOR, UDV
           FROM DISCIPLINE
           WHERE UID7=:UID_D
           INTO :DISCIPLIN, :OTL, :HOR, :UDV
       DO
           BEGIN
             SUSPEND;
           END
   END
END ^

CREATE PROCEDURE ADD_QUEST (UID8 INTEGER, TYPEQUEST INTEGER, BALL INTEGER,
                            TEXT BLOB SUB_TYPE 0 SEGMENT SIZE 80, PINK INTEGER, TIME_TEST INTEGER)
RETURNS
       (UID_QUEST integer)
AS
BEGIN
INSERT INTO QUESTS VALUES (1, :UID8, :TYPEQUEST, :BALL, :TEXT, :PINK, :TIME_TEST);

FOR SELECT MAX(UID9)
    FROM QUESTS
    INTO :UID_QUEST
DO
    BEGIN
      SUSPEND;
    END

END ^

CREATE PROCEDURE ANSWERS(UID_Q integer)
RETURNS
        (NUMBER integer, TEXTANSW BLOB SUB_TYPE 0 SEGMENT SIZE 80,
          ROLES	 INTEGER, PINC BLOB SUB_TYPE 0 SEGMENT SIZE 80)
AS
BEGIN
FOR SELECT NUMBER, TEXTANSW, ROLES
    FROM ANSWER
    WHERE UID9=:UID_Q
    INTO :NUMBER, :TEXTANSW, :ROLES
DO
   BEGIN
          PINC = NULL;
          SELECT PINC
          FROM PINCS
          WHERE (UID9=:UID_Q)AND(NUMBER=:NUMBER)
          INTO :PINC;

          SUSPEND;

   END
END ^


CREATE PROCEDURE ADD_TEST ( UID8	INTEGER,
                            TYPETEST	INTEGER,
                            NAME	BLOB SUB_TYPE 0 SEGMENT SIZE 80,
                            TIMES	INTEGER,
                            BALLTEST	INTEGER,
                            DATATEST	BLOB SUB_TYPE 0 SEGMENT SIZE 80,
                            PS	BLOB SUB_TYPE 0 SEGMENT SIZE 80,
                            NQuest               INTEGER)
RETURNS
       (UIDTEST integer)
AS
BEGIN
INSERT INTO TESTS VALUES (1, :UID8, :TYPETEST, :NAME, :TIMES, :BALLTEST, :DATATEST, :PS, :NQuest);

FOR SELECT MAX(UIDTEST)
    FROM TESTS
    INTO :UIDTEST
DO
    BEGIN
     SUSPEND;
    END

END ^

CREATE PROCEDURE QUESTS_FOR_Test(UID_D integer, SHIFRRAZDEL VARCHAR(60) CHARACTER SET WIN1251)
RETURNS
        (UID9	INTEGER,
         TYPEQUEST INTEGER,
         BALL	INTEGER,
         TEXT	BLOB SUB_TYPE 0 SEGMENT SIZE 80,
         TIME_TEST INTEGER)
AS
DECLARE VARIABLE UID_R INTEGER;
BEGIN

FOR SELECT UID8
    FROM RAZDEL
    WHERE (UID7=:UID_D)AND(SHIFRRAZDEL LIKE :SHIFRRAZDEL)
    INTO :UID_R
DO
   BEGIN
        FOR  SELECT  UID9 ,
                     TYPEQUEST,
                     BALL,
                     TEXT,
                     TIME_TEST
             FROM QUESTS
             WHERE UID8=:UID_R
             INTO :UID9, :TYPEQUEST, :BALL, :TEXT, :TIME_TEST
        DO
         BEGIN
             SUSPEND;
         END
   END
END ^

CREATE PROCEDURE Student_Tests (UID_S integer)
RETURNS
        ( UIDTEST    INTEGER,
          NAMERAZDEL VARCHAR(300) CHARACTER SET WIN1251,
          NAMETEST   BLOB SUB_TYPE 0 SEGMENT SIZE 80,
          DATEEND    BLOB SUB_TYPE 0 SEGMENT SIZE 80,
          METOD	     BLOB SUB_TYPE 0 SEGMENT SIZE 80,
          TUTER      INTEGER)
AS
DECLARE VARIABLE UID_R INTEGER;
BEGIN

FOR SELECT UIDTEST, DATEEND, METOD, TUTER
    FROM STUDENTTESTS
    WHERE UID2=:UID_S
    INTO :UIDTEST, :DATEEND, :METOD, :TUTER
DO
   BEGIN
        FOR  SELECT UID8, NAME
             FROM TESTS
             WHERE UIDTEST=:UIDTEST
             INTO :UID_R, :NAMETEST
        DO
         BEGIN
             FOR  SELECT NAMERAZDEL
                  FROM RAZDEL
                  WHERE UID8=:UID_R
                  INTO :NAMERAZDEL
             DO
               BEGIN
                  SUSPEND;
               END
         END
   END
END ^

CREATE PROCEDURE TEST_QUEST(UIDTEST integer)
RETURNS
        (UID9	INTEGER,
         NUMBERQUEST	INTEGER,
         TYPEQUEST INTEGER,
         TEXT	BLOB SUB_TYPE 0 SEGMENT SIZE 80,
         BALL	INTEGER,
         TIME_TEST INTEGER,
         PINC BLOB SUB_TYPE 0 SEGMENT SIZE 80,
         Y INTEGER)
AS
BEGIN
FOR SELECT UID9, NUMBERQUEST
    FROM TESTQUEST
    WHERE UIDTEST=:UIDTEST
    INTO :UID9, :NUMBERQUEST
DO
   BEGIN
      FOR SELECT TYPEQUEST, BALL, TEXT, TIME_TEST
          FROM QUESTS
          WHERE UID9=:UID9
          INTO :TYPEQUEST, :BALL, :TEXT, :TIME_TEST
      DO
       BEGIN
          PINC = NULL;
          Y = NULL;
          SELECT PINC, Y
          FROM PINCS
          WHERE (UID9=:UID9)AND(NUMBER=0)
          INTO :PINC, :Y;

          SUSPEND;
       END
   END
END ^

CREATE PROCEDURE Gruop_DISCIPLIN (Gruop VARCHAR(20) CHARACTER SET WIN1251)
RETURNS
        (UID_D integer,
         DISCIPLIN VARCHAR(300) CHARACTER SET WIN1251,
         OTL	INTEGER,
         HOR	INTEGER,
         UDV	INTEGER)
AS
BEGIN
FOR SELECT DISTINCT UID7
    FROM CONECTTABEL1
    WHERE GRUOP=:Gruop
    INTO :UID_D
DO
   BEGIN
       FOR SELECT DISCIPLINE, OTL, HOR, UDV
           FROM DISCIPLINE
           WHERE UID7=:UID_D
           INTO :DISCIPLIN, :OTL, :HOR, :UDV
       DO
           BEGIN
             SUSPEND;
           END
   END
END ^

CREATE PROCEDURE Student_Tests_Discipline (UID_S integer, UID_D integer)
RETURNS
        ( UIDTEST    INTEGER,
          NAMERAZDEL VARCHAR(300) CHARACTER SET WIN1251,
          NAMETEST   BLOB SUB_TYPE 0 SEGMENT SIZE 80,
          TYPETEST	INTEGER,
          TIMES 	INTEGER,
          BALLTEST	INTEGER,
          PS	        BLOB SUB_TYPE 0 SEGMENT SIZE 80,
          NQUEST	INTEGER,
          DATEEND    BLOB SUB_TYPE 0 SEGMENT SIZE 80,
          METOD	     BLOB SUB_TYPE 0 SEGMENT SIZE 80,
          TUTER      INTEGER)
AS
DECLARE VARIABLE UID_R INTEGER;
BEGIN

FOR SELECT UIDTEST, DATEEND, METOD, TUTER
    FROM STUDENTTESTS
    WHERE UID2=:UID_S
    INTO :UIDTEST, :DATEEND, :METOD, :TUTER
DO
   BEGIN
        FOR  SELECT UID8, NAME, TYPETEST, TIMES, BALLTEST, PS, NQUEST
             FROM TESTS
             WHERE UIDTEST=:UIDTEST
             INTO :UID_R, :NAMETEST, :TYPETEST, :TIMES, :BALLTEST, :PS, :NQUEST
        DO
         BEGIN
             FOR  SELECT NAMERAZDEL
                  FROM RAZDEL
                  WHERE (UID8=:UID_R)AND(UID7=:UID_D)
                  INTO :NAMERAZDEL
             DO
               BEGIN
                  SUSPEND;
               END
         END
   END
END ^

CREATE PROCEDURE STATISTIK_For_Student(UID_S integer, UID_D integer)
RETURNS
        ( UIDSTAT	INTEGER,
          UID6      	INTEGER,

          UIDTEST	INTEGER,
          NAMERAZDEL	VARCHAR(300) CHARACTER SET WIN1251,
          NAME_Test  	BLOB SUB_TYPE 0 SEGMENT SIZE 80,

          STUDENTBALL	FLOAT,
          PROCENT 	FLOAT,
          DATASDACHI	VARCHAR(100) CHARACTER SET WIN1251,
          PS	        VARCHAR(300) CHARACTER SET WIN1251)
AS
DECLARE VARIABLE UID_R INTEGER;
BEGIN

FOR SELECT UIDSTAT, UID6, UIDTEST, STUDENTBALL, PROCENT, DATASDACHI, PS
    FROM STATISTIK
    WHERE UID2=:UID_S
    INTO :UIDSTAT, :UID6, :UIDTEST, :STUDENTBALL, :PROCENT, :DATASDACHI, :PS
DO
   BEGIN
        FOR  SELECT  UID8, NAME
             FROM TESTS
             WHERE UIDTEST=:UIDTEST
             INTO :UID_R, :NAME_Test
        DO
         BEGIN
             FOR  SELECT NAMERAZDEL
                  FROM RAZDEL
                  WHERE (UID8=:UID_R)AND(UID7=:UID_D)
                  INTO :NAMERAZDEL
             DO
             BEGIN
               SUSPEND;
             END
         END
   END
END ^

SET TERM ; ^



